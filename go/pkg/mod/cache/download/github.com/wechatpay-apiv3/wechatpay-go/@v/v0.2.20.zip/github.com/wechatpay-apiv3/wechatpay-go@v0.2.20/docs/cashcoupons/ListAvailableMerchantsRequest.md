# ListAvailableMerchantsRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**Offset** | **int64** | 分页页码，最大1000 | 
**Limit** | **int64** | 分页大小，最大50 | 
**StockCreatorMchid** | **string** | 批次创建方商户号 | 
**StockId** | **string** | 批次号 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


