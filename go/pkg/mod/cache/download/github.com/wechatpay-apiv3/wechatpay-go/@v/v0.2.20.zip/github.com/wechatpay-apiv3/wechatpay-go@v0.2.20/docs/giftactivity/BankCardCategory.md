# BankCardCategory

## 枚举


* `DEBIT_CARD` (value: `"DEBIT_CARD"`)

* `CREDIT_CARD` (value: `"CREDIT_CARD"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


