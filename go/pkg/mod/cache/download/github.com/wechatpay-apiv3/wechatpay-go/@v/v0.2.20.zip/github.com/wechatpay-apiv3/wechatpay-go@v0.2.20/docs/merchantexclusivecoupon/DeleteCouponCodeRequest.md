# DeleteCouponCodeRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**StockId** | **string** | 商家券批次号 | 
**CouponCode** | **string** | 上传的自定义code | 
**DeleteRequestNo** | **string** | 商户删除code的凭据号，商户侧需保持唯一性 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


