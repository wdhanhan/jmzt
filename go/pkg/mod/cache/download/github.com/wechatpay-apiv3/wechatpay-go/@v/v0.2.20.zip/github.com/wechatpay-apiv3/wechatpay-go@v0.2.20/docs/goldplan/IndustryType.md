# IndustryType

同业过滤标签枚举值

## 枚举


* `E_COMMERCE` (value: `"E_COMMERCE"`)

* `LOVE_MARRIAGE` (value: `"LOVE_MARRIAGE"`)

* `POTOGRAPHY` (value: `"POTOGRAPHY"`)

* `EDUCATION` (value: `"EDUCATION"`)

* `FINANCE` (value: `"FINANCE"`)

* `TOURISM` (value: `"TOURISM"`)

* `SKINCARE` (value: `"SKINCARE"`)

* `FOOD` (value: `"FOOD"`)

* `SPORT` (value: `"SPORT"`)

* `JEWELRY_WATCH` (value: `"JEWELRY_WATCH"`)

* `HEALTHCARE` (value: `"HEALTHCARE"`)

* `BUSSINESS` (value: `"BUSSINESS"`)

* `PARENTING` (value: `"PARENTING"`)

* `CATERING` (value: `"CATERING"`)

* `RETAIL` (value: `"RETAIL"`)

* `SERVICES` (value: `"SERVICES"`)

* `LAW` (value: `"LAW"`)

* `ESTATE` (value: `"ESTATE"`)

* `TRANSPORTATION` (value: `"TRANSPORTATION"`)

* `ENERGY_SAVING` (value: `"ENERGY_SAVING"`)

* `SECURITY` (value: `"SECURITY"`)

* `BUILDING_MATERIAL` (value: `"BUILDING_MATERIAL"`)

* `COMMUNICATION` (value: `"COMMUNICATION"`)

* `MERCHANDISE` (value: `"MERCHANDISE"`)

* `ASSOCIATION` (value: `"ASSOCIATION"`)

* `COMMUNITY` (value: `"COMMUNITY"`)

* `ONLINE_AVR` (value: `"ONLINE_AVR"`)

* `WE_MEDIA` (value: `"WE_MEDIA"`)

* `CAR` (value: `"CAR"`)

* `SOFTWARE` (value: `"SOFTWARE"`)

* `GAME` (value: `"GAME"`)

* `CLOTHING` (value: `"CLOTHING"`)

* `INDUSTY` (value: `"INDUSTY"`)

* `AGRICULTURE` (value: `"AGRICULTURE"`)

* `PUBLISHING_MEDIA` (value: `"PUBLISHING_MEDIA"`)

* `HOME_DIGITAL` (value: `"HOME_DIGITAL"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


