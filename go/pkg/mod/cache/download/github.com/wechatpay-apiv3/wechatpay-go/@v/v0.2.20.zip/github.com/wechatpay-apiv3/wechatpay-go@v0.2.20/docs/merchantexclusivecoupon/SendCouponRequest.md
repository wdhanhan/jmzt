# SendCouponRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**Openid** | **string** | 用户的唯一标识，必填 | 
**Appid** | **string** | 发券方AppID | 
**StockId** | **string** | 批次号 | 
**OutRequestNo** | **string** | 发券凭证，可包含英文字母，数字，｜，_，*，-等内容，不允许出现其他不合法符号，需在单个批次单个用户下确保唯一性 | 
**CouponCode** | **string** | 要求接口指定code发券的批次必传 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


