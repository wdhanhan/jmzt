# PaymentScene

## 枚举


* `APP_SCENE` (value: `"APP_SCENE"`)

* `SWING_CARD_SCENE` (value: `"SWING_CARD_SCENE"`)

* `NO_SECRET_SCENE` (value: `"NO_SECRET_SCENE"`)

* `MINIAPP_SCENE` (value: `"MINIAPP_SCENE"`)

* `FACE_PAY_SCENE` (value: `"FACE_PAY_SCENE"`)

* `OTHER_SCENE` (value: `"OTHER_SCENE"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


