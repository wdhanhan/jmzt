# ListAuthenticationsResponse

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**Data** | [**[]AuthenticationEntity**](AuthenticationEntity.md) | 查询结果记录列表 | [可选] 
**TotalCount** | **int64** | 经过条件筛选，查询到的记录总数 | 
**Offset** | **int64** | 该次请求资源的起始位置，请求中包含偏移量时应答消息返回相同偏移量，否则返回默认值0 | 
**Limit** | **int64** | 经过条件筛选，本次查询到的记录条数 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


