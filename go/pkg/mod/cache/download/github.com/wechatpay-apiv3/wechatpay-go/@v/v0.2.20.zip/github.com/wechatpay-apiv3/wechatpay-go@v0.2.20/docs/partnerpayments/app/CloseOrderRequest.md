# CloseOrderRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**OutTradeNo** | **string** | 商户订单号 | 
**SpMchid** | **string** | 服务商户号，由微信支付生成并下发  | 
**SubMchid** | **string** | 子商户的商户号，由微信支付生成并下发  | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


