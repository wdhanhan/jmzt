# ReturnOrderStatus

  * &#x60;PROCESSING&#x60; - 处理中，  * &#x60;SUCCESS&#x60; - 已成功，  * &#x60;FAILED&#x60; - 已失败，

## 枚举


* `PROCESSING` (value: `"PROCESSING"`)

* `SUCCESS` (value: `"SUCCESS"`)

* `FAILED` (value: `"FAILED"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


