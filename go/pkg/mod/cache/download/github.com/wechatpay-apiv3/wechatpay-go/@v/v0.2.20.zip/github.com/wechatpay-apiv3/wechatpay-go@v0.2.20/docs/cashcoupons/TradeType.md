# TradeType

## 枚举


* `MICROAPP` (value: `"MICROAPP"`)

* `APPPAY` (value: `"APPPAY"`)

* `PPAY` (value: `"PPAY"`)

* `CARD` (value: `"CARD"`)

* `FACE` (value: `"FACE"`)

* `OTHER` (value: `"OTHER"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


