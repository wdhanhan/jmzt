# ListActivityMerchantRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**ActivityId** | **string** | 活动Id | 
**Offset** | **int64** | 分页页码 | [可选] 
**Limit** | **int64** | 限制分页最大数据条目 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


