# BusiFavorStockType

## 枚举


* `NORMAL` (value: `"NORMAL"`)

* `DISCOUNT` (value: `"DISCOUNT"`)

* `EXCHANGE` (value: `"EXCHANGE"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


