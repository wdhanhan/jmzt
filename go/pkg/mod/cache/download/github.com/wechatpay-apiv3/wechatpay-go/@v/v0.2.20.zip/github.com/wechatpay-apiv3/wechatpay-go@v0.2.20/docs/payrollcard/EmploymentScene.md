# EmploymentScene

## 枚举


* `LOGISTICS` (value: `"LOGISTICS"`)

* `MANUFACTURING` (value: `"MANUFACTURING"`)

* `HOTEL` (value: `"HOTEL"`)

* `CATERING` (value: `"CATERING"`)

* `EVENT` (value: `"EVENT"`)

* `RETAIL` (value: `"RETAIL"`)

* `OTHERS` (value: `"OTHERS"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


