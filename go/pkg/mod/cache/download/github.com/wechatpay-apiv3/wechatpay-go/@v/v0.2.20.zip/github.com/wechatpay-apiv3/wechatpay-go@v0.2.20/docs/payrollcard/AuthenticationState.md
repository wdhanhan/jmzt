# AuthenticationState

## 枚举


* `PROCESSING` (value: `"AUTHENTICATE_PROCESSING"`)

* `SUCCESS` (value: `"AUTHENTICATE_SUCCESS"`)

* `FAILED` (value: `"AUTHENTICATE_FAILED"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


