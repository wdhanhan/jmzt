# BackgroundColor

## 枚举


* `COLOR010` (value: `"COLOR010"`)

* `COLOR020` (value: `"COLOR020"`)

* `COLOR030` (value: `"COLOR030"`)

* `COLOR040` (value: `"COLOR040"`)

* `COLOR050` (value: `"COLOR050"`)

* `COLOR060` (value: `"COLOR060"`)

* `COLOR070` (value: `"COLOR070"`)

* `COLOR080` (value: `"COLOR080"`)

* `COLOR081` (value: `"COLOR081"`)

* `COLOR082` (value: `"COLOR082"`)

* `COLOR090` (value: `"COLOR090"`)

* `COLOR100` (value: `"COLOR100"`)

* `COLOR101` (value: `"COLOR101"`)

* `COLOR102` (value: `"COLOR102"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


