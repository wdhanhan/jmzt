# SendMerchantOption

## 枚举


* `IN_SEVICE_COUPON_MERCHANT` (value: `"IN_SEVICE_COUPON_MERCHANT"`)

* `MANUAL_INPUT_MERCHANT` (value: `"MANUAL_INPUT_MERCHANT"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


