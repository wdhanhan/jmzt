# DeleteActivityMerchantBody

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**MerchantIdList** | **[]string** | 从活动已有的发券商户号中移除的商户号列表 | 
**DeleteRequestNo** | **string** | 商户添加发券商户号的凭据号，商户侧需保持唯一性 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


