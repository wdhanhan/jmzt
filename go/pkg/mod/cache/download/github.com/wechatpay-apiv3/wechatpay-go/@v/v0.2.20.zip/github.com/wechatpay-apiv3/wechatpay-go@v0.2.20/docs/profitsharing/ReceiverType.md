# ReceiverType

  * &#x60;MERCHANT_ID&#x60; - 商户号，  * &#x60;PERSONAL_OPENID&#x60; - 个人openid（由父商户APPID转换得到），  * &#x60;PERSONAL_SUB_OPENID&#x60; - 个人sub_openid（由子商户APPID转换得到）（直连商户不需要，服务商需要），

## 枚举


* `MERCHANT_ID` (value: `"MERCHANT_ID"`)

* `PERSONAL_OPENID` (value: `"PERSONAL_OPENID"`)

* `PERSONAL_SUB_OPENID` (value: `"PERSONAL_SUB_OPENID"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


