# AwardBaseInfo

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**StockId** | **string** | 代金券批次Id | 
**OriginalImageUrl** | **string** | 奖品大图，必填 | 
**ThumbnailUrl** | **string** | 奖品小图，当选多张券时必填 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


