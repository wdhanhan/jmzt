# DeactivateCouponRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**CouponCode** | **string** | 券的唯一标识 | 
**StockId** | **string** | 券的所属批次号 | 
**DeactivateRequestNo** | **string** | 每次失效请求的唯一标识，商户需保证唯一 | 
**DeactivateReason** | **string** | 商户失效券的原因 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


