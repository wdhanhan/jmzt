# CouponCollection

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**Data** | [**[]Coupon**](Coupon.md) | 结果集 | [可选] 
**TotalCount** | **int64** | 查询结果总数 | 
**Limit** | **int64** | 分页大小 | 
**Offset** | **int64** | 分页页码 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


