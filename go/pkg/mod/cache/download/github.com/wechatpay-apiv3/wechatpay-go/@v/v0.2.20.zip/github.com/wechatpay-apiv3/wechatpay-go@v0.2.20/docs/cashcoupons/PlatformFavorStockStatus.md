# PlatformFavorStockStatus

## 枚举


* `UNACTIVATED` (value: `"UNACTIVATED"`)

* `RUNNING` (value: `"RUNNING"`)

* `PAUSED` (value: `"PAUSED"`)

* `EXPIRED` (value: `"EXPIRED"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


