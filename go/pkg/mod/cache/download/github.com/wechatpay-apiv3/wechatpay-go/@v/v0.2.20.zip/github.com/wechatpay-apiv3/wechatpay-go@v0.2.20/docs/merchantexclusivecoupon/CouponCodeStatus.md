# CouponCodeStatus

## 枚举


* `AVAILABLE` (value: `"AVAILABLE"`)

* `DISPATCHED` (value: `"DISPATCHED"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


