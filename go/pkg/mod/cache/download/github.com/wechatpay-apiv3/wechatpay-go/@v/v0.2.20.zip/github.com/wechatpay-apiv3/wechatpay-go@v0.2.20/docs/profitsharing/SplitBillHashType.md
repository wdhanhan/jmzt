# SplitBillHashType

  * &#x60;SHA1&#x60; - SHA1，Secure Hash Algorithm 1

## 枚举


* `SHA1` (value: `"SHA1"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


