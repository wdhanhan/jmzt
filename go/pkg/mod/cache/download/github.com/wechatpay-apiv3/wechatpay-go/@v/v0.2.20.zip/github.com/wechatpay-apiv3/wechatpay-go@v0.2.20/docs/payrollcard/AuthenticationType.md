# AuthenticationType

## 枚举


* `NORMAL` (value: `"NORMAL"`)

* `SIGN_IN` (value: `"SIGN_IN"`)

* `INSURANCE` (value: `"INSURANCE"`)

* `CONTRACT` (value: `"CONTRACT"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


