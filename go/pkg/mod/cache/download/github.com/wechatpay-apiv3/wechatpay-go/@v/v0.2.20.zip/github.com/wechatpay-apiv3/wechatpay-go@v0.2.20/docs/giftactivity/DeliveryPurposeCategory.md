# DeliveryPurposeCategory

投放目的枚举值

## 枚举


* `OFF_LINE_PAY` (value: `"OFF_LINE_PAY"`)

* `JUMP_MINI_APP` (value: `"JUMP_MINI_APP"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


