# ParticipateMchStatus

## 枚举


* `PARTIC_MCH_STATUS_INVALID` (value: `"PARTIC_MCH_STATUS_INVALID"`)

* `PARTIC_MCH_STATUS_VALID` (value: `"PARTIC_MCH_STATUS_VALID"`)

* `PARTIC_MCH_STATUS_EXPIRE` (value: `"PARTIC_MCH_STATUS_EXPIRE"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


