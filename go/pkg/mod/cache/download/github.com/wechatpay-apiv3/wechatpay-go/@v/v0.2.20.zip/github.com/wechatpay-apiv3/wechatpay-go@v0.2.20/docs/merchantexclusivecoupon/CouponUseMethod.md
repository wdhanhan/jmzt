# CouponUseMethod

## 枚举


* `OFF_LINE` (value: `"OFF_LINE"`)

* `MINI_PROGRAMS` (value: `"MINI_PROGRAMS"`)

* `SELF_CONSUME` (value: `"SELF_CONSUME"`)

* `PAYMENT_CODE` (value: `"PAYMENT_CODE"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


