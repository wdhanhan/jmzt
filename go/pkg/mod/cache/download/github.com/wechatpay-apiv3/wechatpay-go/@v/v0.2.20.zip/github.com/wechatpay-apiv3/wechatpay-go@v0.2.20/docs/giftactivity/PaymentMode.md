# PaymentMode

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**PaymentSceneList** | [**[]PaymentScene**](PaymentScene.md) | APP_SCENE：App场景；SWING_CARD:刷卡;NO_SECRET_SCENE:免密支付;MINIAPP_SCENE:小程序;FACE_PAY_SCENE:人脸支付; OTHER_SCENE:其他支付场景 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


