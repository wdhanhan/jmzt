# ChangeCustomPageStatusRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**SubMchid** | **string** | 开通或关闭“商家自定义小票”的特约商户商户号，由微信支付生成并下发。 | 
**OperationType** | [**OperationType**](OperationType.md) | 开通或关闭“商家自定义小票”的动作，枚举值：  OPEN：表示开通  CLOSE：表示关闭 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


