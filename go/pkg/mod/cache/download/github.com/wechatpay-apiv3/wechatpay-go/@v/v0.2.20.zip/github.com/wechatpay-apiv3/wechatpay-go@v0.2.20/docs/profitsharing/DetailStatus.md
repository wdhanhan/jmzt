# DetailStatus

  * &#x60;PENDING&#x60; - 待分账，  * &#x60;SUCCESS&#x60; - 分账成功，  * &#x60;CLOSED&#x60; - 已关闭，

## 枚举


* `PENDING` (value: `"PENDING"`)

* `SUCCESS` (value: `"SUCCESS"`)

* `CLOSED` (value: `"CLOSED"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


