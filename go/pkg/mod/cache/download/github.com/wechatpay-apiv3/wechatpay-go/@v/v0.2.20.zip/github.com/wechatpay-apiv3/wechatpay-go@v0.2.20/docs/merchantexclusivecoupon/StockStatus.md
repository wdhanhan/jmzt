# StockStatus

## 枚举


* `UNAUDIT` (value: `"UNAUDIT"`)

* `RUNNING` (value: `"RUNNING"`)

* `STOPED` (value: `"STOPED"`)

* `PAUSED` (value: `"PAUSED"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


