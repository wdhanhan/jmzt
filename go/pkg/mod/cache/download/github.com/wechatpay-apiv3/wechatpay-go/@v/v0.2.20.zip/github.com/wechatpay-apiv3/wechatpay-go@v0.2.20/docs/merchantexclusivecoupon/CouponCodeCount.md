# CouponCodeCount

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**TotalCount** | **int64** | 该批次总共已上传的code总数 | 
**AvailableCount** | **int64** | 该批次当前可用的code数 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


