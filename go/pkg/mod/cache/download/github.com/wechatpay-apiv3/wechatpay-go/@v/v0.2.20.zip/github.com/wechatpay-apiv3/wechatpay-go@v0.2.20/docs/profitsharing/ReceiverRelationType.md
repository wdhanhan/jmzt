# ReceiverRelationType

  * &#x60;SERVICE_PROVIDER&#x60; - 服务商，  * &#x60;STORE&#x60; - 门店，  * &#x60;STAFF&#x60; - 员工，  * &#x60;STORE_OWNER&#x60; - 店主，  * &#x60;PARTNER&#x60; - 合作伙伴，  * &#x60;HEADQUARTER&#x60; - 总部，  * &#x60;BRAND&#x60; - 品牌方，  * &#x60;DISTRIBUTOR&#x60; - 分销商，  * &#x60;USER&#x60; - 用户，  * &#x60;SUPPLIER&#x60; - 供应商，  * &#x60;CUSTOM&#x60; - 自定义，

## 枚举


* `SERVICE_PROVIDER` (value: `"SERVICE_PROVIDER"`)

* `STORE` (value: `"STORE"`)

* `STAFF` (value: `"STAFF"`)

* `STORE_OWNER` (value: `"STORE_OWNER"`)

* `PARTNER` (value: `"PARTNER"`)

* `HEADQUARTER` (value: `"HEADQUARTER"`)

* `BRAND` (value: `"BRAND"`)

* `DISTRIBUTOR` (value: `"DISTRIBUTOR"`)

* `USER` (value: `"USER"`)

* `SUPPLIER` (value: `"SUPPLIER"`)

* `CUSTOM` (value: `"CUSTOM"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


