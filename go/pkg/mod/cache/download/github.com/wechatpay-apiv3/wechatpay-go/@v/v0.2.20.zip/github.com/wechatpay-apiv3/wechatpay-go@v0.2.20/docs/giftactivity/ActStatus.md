# ActStatus

## 枚举


* `ACT_STATUS_UNKNOWN` (value: `"ACT_STATUS_UNKNOWN"`)

* `CREATE_ACT_STATUS` (value: `"CREATE_ACT_STATUS"`)

* `ONGOING_ACT_STATUS` (value: `"ONGOING_ACT_STATUS"`)

* `TERMINATE_ACT_STATUS` (value: `"TERMINATE_ACT_STATUS"`)

* `STOP_ACT_STATUS` (value: `"STOP_ACT_STATUS"`)

* `OVER_TIME_ACT_STATUS` (value: `"OVER_TIME_ACT_STATUS"`)

* `CREATE_ACT_FAILED` (value: `"CREATE_ACT_FAILED"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


