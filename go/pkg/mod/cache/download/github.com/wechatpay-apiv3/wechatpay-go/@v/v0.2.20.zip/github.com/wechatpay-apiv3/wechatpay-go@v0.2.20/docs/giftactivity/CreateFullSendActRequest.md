# CreateFullSendActRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**ActivityBaseInfo** | [**ActBaseInfo**](ActBaseInfo.md) | 用于创建活动的基本信息 | 
**AwardSendRule** | [**FullSendRule**](FullSendRule.md) | 满送活动规则 | 
**AdvancedSetting** | [**ActAdvancedSetting**](ActAdvancedSetting.md) | 其他高级配置项 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


