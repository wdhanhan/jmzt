#include "scanning.h"


void vnumber(const GoString *src, long *p, JsonState *ret) {
    return vnumber_1(src, p, ret);
}